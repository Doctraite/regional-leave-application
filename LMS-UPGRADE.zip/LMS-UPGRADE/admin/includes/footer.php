<div class="footer-wrap pd-20 mb-20 card-box">
&copy Regional Health Leave Management System &copy <a href="#" target="_blank"><span>Developer (s) : </a></span> S.Shongwe & Z.Mhlanga 
			</div>